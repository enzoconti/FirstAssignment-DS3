#ifndef GLOBALVALUES_H
#define GLOBALVALUES_H

#define CLUSTERSIZE 960 // this is the pre-stabilished size of the cluster("pagina de disco" on PT-BR)
#define LINESIZE 100 // this is the upper-value of the line of the CSV










#endif